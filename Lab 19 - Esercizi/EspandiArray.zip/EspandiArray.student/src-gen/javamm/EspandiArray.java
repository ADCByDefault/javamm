package javamm;

@SuppressWarnings("all")
public class EspandiArray {
  public static int[][] espandiArray(int[] V) {
    return null;
  }
  
  public static void main(String[] args) {
  }
}
