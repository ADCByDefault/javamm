package javamm;

@SuppressWarnings("all")
public class Matrice {
  public static boolean piramide(byte[][] M, int k) {
    return false;
  }
  
  public static int altezzaMassimaPiramide(byte[][] M) {
    return 0;
  }
  
  public static void main(String[] args) {
  }
}
