package javamm;

@SuppressWarnings("all")
public class AzzeraNonUnici {
  public static int[][] azzeraNonUnici(int[][] M, int r, int c) {
    return null;
  }
  
  public static int[][] azzeraNonUniciMatrice(int[][] M) {
    return null;
  }
  
  public static void main(String[] args) {
  }
}
