package javamm;

@SuppressWarnings("all")
public class VisitaSerpentina {
  public static int[] visitaSerpentina(int[][] M, int riga, int colonna) {
    return null;
  }
  
  public static void main(String[] args) {
  }
}
