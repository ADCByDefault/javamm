package javamm;

@SuppressWarnings("all")
public class Diagonali {
  public static byte[][] generaMatrice(byte[] arr) {
    return null;
  }
  
  public static byte[] riduciMatrice(byte[][] M) {
    return null;
  }
  
  public static void main(String[] args) {
  }
}
