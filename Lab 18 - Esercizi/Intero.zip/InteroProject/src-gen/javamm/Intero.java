package javamm;

@SuppressWarnings("all")
public class Intero {
  public static boolean bilanciato(int n) {
    return false;
  }
  
  public static void main(String[] args) {
  }
}
