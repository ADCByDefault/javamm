package javamm;

@SuppressWarnings("all")
public class Intero {
  public static int comprimi(int n, byte k) {
    return 0;
  }
  
  public static int espandi(int n, byte k) {
    return 0;
  }
  
  public static boolean connessi(int n1, int n2, byte k) {
    return false;
  }
  
  public static void main(String[] args) {
  }
}
