package javamm;

@SuppressWarnings("all")
public class Circolare {
  public static boolean circolare(char[][] M) {
    return false;
  }
  
  public static boolean circolareInversa(char[][] M) {
    return false;
  }
  
  public static void main(String[] args) {
  }
}
