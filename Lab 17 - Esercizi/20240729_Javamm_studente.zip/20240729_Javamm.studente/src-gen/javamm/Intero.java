package javamm;

@SuppressWarnings("all")
public class Intero {
  public static int inverti(int n, byte k) {
    return 0;
  }
  
  public static boolean collegati(int n, int m, byte k) {
    return false;
  }
  
  public static void main(String[] args) {
  }
}
