package javamm;

@SuppressWarnings("all")
public class Anelli {
  public static boolean anelloBilanciato(int[][] T, int k) {
    return false;
  }
  
  public static void main(String[] args) {
  }
}
